'use client'

import { useEffect, useState } from 'react'

interface Mensaje {
  id: string
  mensajeRecibido: string
  mensajeEnviado: string | null
  respondido: boolean
  tipo: string
  createdAt: string
  fan: {
    nombre: string | null
    facebookId: string
    totalMensajes: number
  }
}

interface Stats {
  totalMensajes: number
  totalFans: number
  respondidos: number
}

export default function Home() {
  const [mensajes, setMensajes] = useState<Mensaje[]>([])
  const [stats, setStats] = useState<Stats>({ totalMensajes: 0, totalFans: 0, respondidos: 0 })
  const [loading, setLoading] = useState(true)
  const [webhookUrl, setWebhookUrl] = useState('')

  useEffect(() => {
    // Obtener la URL actual para mostrar el webhook
    if (typeof window !== 'undefined') {
      const host = window.location.host
      setWebhookUrl(`https://${host}/api/webhook/facebook`)
    }

    // Cargar datos
    cargarDatos()
  }, [])

  const cargarDatos = async () => {
    try {
      const res = await fetch('/api/dashboard')
      const data = await res.json()
      setMensajes(data.mensajes || [])
      setStats(data.stats || { totalMensajes: 0, totalFans: 0, respondidos: 0 })
    } catch (error) {
      console.error('Error cargando datos:', error)
    } finally {
      setLoading(false)
    }
  }

  const copiarUrl = () => {
    navigator.clipboard.writeText(webhookUrl)
    alert('URL copiada al portapapeles!')
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-2">🎭 Louis le Raté - Chatbot</h1>
          <p className="text-gray-400">Panel de control del bot de Facebook Messenger</p>
        </div>

        {/* Webhook URL */}
        <div className="bg-gray-800 rounded-lg p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4">📡 Webhook URL</h2>
          <div className="flex gap-2">
            <input
              type="text"
              value={webhookUrl}
              readOnly
              className="flex-1 bg-gray-700 rounded px-4 py-2 text-sm font-mono"
            />
            <button
              onClick={copiarUrl}
              className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded font-medium transition"
            >
              Copiar
            </button>
          </div>
          <p className="text-gray-400 text-sm mt-2">
            Usa esta URL en Facebook Developers → Messenger → Configuración → Webhooks
          </p>
          <p className="text-yellow-400 text-sm mt-1">
            Verify Token: <code className="bg-gray-700 px-2 py-1 rounded">mi_token_secreto_123</code>
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="bg-gray-800 rounded-lg p-6 text-center">
            <div className="text-4xl font-bold text-blue-400">{stats.totalMensajes}</div>
            <div className="text-gray-400">Mensajes Recibidos</div>
          </div>
          <div className="bg-gray-800 rounded-lg p-6 text-center">
            <div className="text-4xl font-bold text-green-400">{stats.totalFans}</div>
            <div className="text-gray-400">Fans</div>
          </div>
          <div className="bg-gray-800 rounded-lg p-6 text-center">
            <div className="text-4xl font-bold text-purple-400">{stats.respondidos}</div>
            <div className="text-gray-400">Respondidos</div>
          </div>
        </div>

        {/* Mensajes */}
        <div className="bg-gray-800 rounded-lg p-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold">💬 Mensajes Recientes</h2>
            <button
              onClick={cargarDatos}
              className="bg-gray-700 hover:bg-gray-600 px-4 py-2 rounded text-sm transition"
            >
              🔄 Actualizar
            </button>
          </div>

          {loading ? (
            <div className="text-center py-8 text-gray-400">Cargando...</div>
          ) : mensajes.length === 0 ? (
            <div className="text-center py-8 text-gray-400">
              <p className="text-6xl mb-4">📭</p>
              <p>No hay mensajes todavía.</p>
              <p className="text-sm mt-2">Los mensajes aparecerán aquí cuando los fans escriban.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {mensajes.map((msg) => (
                <div key={msg.id} className="bg-gray-700 rounded-lg p-4">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <span className="font-medium">{msg.fan.nombre || 'Fan'}</span>
                      <span className="text-gray-400 text-sm ml-2">
                        ({msg.fan.totalMensajes} mensajes)
                      </span>
                    </div>
                    <div className="flex gap-2">
                      {msg.respondido ? (
                        <span className="bg-green-600 text-xs px-2 py-1 rounded">✓ Respondido</span>
                      ) : (
                        <span className="bg-yellow-600 text-xs px-2 py-1 rounded">⏳ Pendiente</span>
                      )}
                      <span className="bg-gray-600 text-xs px-2 py-1 rounded">{msg.tipo}</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="bg-gray-600 rounded p-3">
                      <div className="text-xs text-gray-400 mb-1">📩 Recibido:</div>
                      <div>{msg.mensajeRecibido}</div>
                    </div>
                    {msg.mensajeEnviado && (
                      <div className="bg-blue-900/50 rounded p-3">
                        <div className="text-xs text-blue-300 mb-1">📤 Enviado:</div>
                        <div>{msg.mensajeEnviado}</div>
                      </div>
                    )}
                  </div>
                  <div className="text-xs text-gray-500 mt-2">
                    {new Date(msg.createdAt).toLocaleString()}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Instrucciones */}
        <div className="bg-gray-800 rounded-lg p-6 mt-6">
          <h2 className="text-xl font-semibold mb-4">📋 Pasos para conectar con Facebook</h2>
          <ol className="list-decimal list-inside space-y-2 text-gray-300">
            <li>Ve a <a href="https://developers.facebook.com/apps/25872197969145859/messenger/settings/" target="_blank" className="text-blue-400 hover:underline">Facebook Developers</a></li>
            <li>En Messenger → Configuración, agrega el webhook URL de arriba</li>
            <li>Usa el Verify Token: <code className="bg-gray-700 px-2 py-1 rounded">mi_token_secreto_123</code></li>
            <li>Suscribe los eventos: <code className="bg-gray-700 px-1 rounded">messages</code> y <code className="bg-gray-700 px-1 rounded">comments</code></li>
            <li>¡Listo! El bot responderá automáticamente a mensajes y comentarios</li>
          </ol>
        </div>
      </div>
    </div>
  )
}
