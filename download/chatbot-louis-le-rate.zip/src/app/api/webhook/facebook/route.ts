import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

const VERIFY_TOKEN = process.env.FACEBOOK_VERIFY_TOKEN || 'mi_token_secreto_123';
const PAGE_ACCESS_TOKEN = process.env.FACEBOOK_PAGE_ACCESS_TOKEN;

// GET - Verificación del webhook por Facebook
export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const mode = searchParams.get('hub.mode');
  const token = searchParams.get('hub.verify_token');
  const challenge = searchParams.get('hub.challenge');

  console.log('[WEBHOOK] Verificación recibida:', { mode, token, challenge });

  if (mode === 'subscribe' && token === VERIFY_TOKEN) {
    console.log('[WEBHOOK] ✅ Webhook verificado correctamente');
    return new NextResponse(challenge, { status: 200 });
  }

  console.log('[WEBHOOK] ❌ Verificación fallida');
  return NextResponse.json({ error: 'Verificación fallida' }, { status: 403 });
}

// POST - Recibir mensajes de Facebook
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    console.log('[WEBHOOK] Mensaje recibido:', JSON.stringify(body, null, 2));

    // Verificar que es un mensaje de página
    if (body.object !== 'page') {
      return NextResponse.json({ status: 'ignored' }, { status: 200 });
    }

    // Procesar cada entrada
    for (const entry of body.entry || []) {
      // Procesar mensajes privados
      for (const messaging of entry.messaging || []) {
        await processMessage(messaging);
      }

      // Procesar comentarios en posts/videos
      for (const change of entry.changes || []) {
        if (change.field === 'comments') {
          await processComment(change.value);
        }
      }
    }

    return NextResponse.json({ status: 'ok' }, { status: 200 });
  } catch (error) {
    console.error('[WEBHOOK] Error:', error);
    return NextResponse.json({ error: 'Error procesando mensaje' }, { status: 500 });
  }
}

// Procesar mensaje privado
async function processMessage(messaging: any) {
  const senderId = messaging.sender?.id;
  const messageText = messaging.message?.text;

  if (!senderId || !messageText) {
    console.log('[WEBHOOK] Mensaje sin texto o sender, ignorando');
    return;
  }

  console.log(`[WEBHOOK] 💬 Mensaje de ${senderId}: "${messageText}"`);

  // Buscar o crear fan
  let fan = await db.fan.findUnique({
    where: { facebookId: senderId }
  });

  if (!fan) {
    // Obtener nombre del usuario desde Facebook
    const userName = await getUserName(senderId);
    fan = await db.fan.create({
      data: {
        facebookId: senderId,
        nombre: userName,
        totalMensajes: 1,
        ultimoMensaje: new Date()
      }
    });
    console.log(`[WEBHOOK] 👤 Nuevo fan creado: ${userName}`);
  } else {
    // Actualizar fan existente
    await db.fan.update({
      where: { id: fan.id },
      data: {
        totalMensajes: { increment: 1 },
        ultimoMensaje: new Date()
      }
    });
  }

  // Guardar mensaje
  const mensaje = await db.mensaje.create({
    data: {
      fanId: fan.id,
      mensajeRecibido: messageText,
      tipo: 'mensaje',
      respondido: false
    }
  });

  console.log(`[WEBHOOK] 📝 Mensaje guardado con ID: ${mensaje.id}`);

  // Generar respuesta con IA inmediatamente (sin delay para pruebas)
  await generateAndSendResponse(mensaje, fan);
}

// Procesar comentario en video/post
async function processComment(commentData: any) {
  const commentId = commentData.comment_id;
  const message = commentData.message;
  const postId = commentData.post_id;
  const from = commentData.from;

  if (!from?.id || !message) return;

  console.log(`[WEBHOOK] 🎬 Comentario en video: "${message}"`);

  // Buscar o crear fan
  let fan = await db.fan.findUnique({
    where: { facebookId: from.id }
  });

  if (!fan) {
    fan = await db.fan.create({
      data: {
        facebookId: from.id,
        nombre: from.name || 'Fan',
        totalMensajes: 1,
        ultimoMensaje: new Date()
      }
    });
  } else {
    await db.fan.update({
      where: { id: fan.id },
      data: {
        totalMensajes: { increment: 1 },
        ultimoMensaje: new Date()
      }
    });
  }

  // Guardar comentario
  const mensaje = await db.mensaje.create({
    data: {
      fanId: fan.id,
      mensajeRecibido: message,
      tipo: 'comentario',
      postId: postId,
      respondido: false
    }
  });

  console.log(`[WEBHOOK] 📝 Comentario guardado con ID: ${mensaje.id}`);

  // Responder al comentario
  await respondToComment(commentId, mensaje, fan);
}

// Obtener nombre del usuario desde Facebook
async function getUserName(userId: string): Promise<string> {
  try {
    const response = await fetch(
      `https://graph.facebook.com/v18.0/${userId}?fields=name&access_token=${PAGE_ACCESS_TOKEN}`
    );
    const data = await response.json();
    return data.name || 'Fan';
  } catch {
    return 'Fan';
  }
}

// Generar respuesta con IA y enviar
async function generateAndSendResponse(mensaje: any, fan: any) {
  try {
    // Generar respuesta con IA
    const respuesta = await generateAIResponse(mensaje.mensajeRecibido, fan);

    // Enviar respuesta a Facebook
    const sent = await sendFacebookMessage(fan.facebookId, respuesta);

    if (sent) {
      // Actualizar mensaje como respondido
      await db.mensaje.update({
        where: { id: mensaje.id },
        data: {
          mensajeEnviado: respuesta,
          respondido: true,
          fechaRespuesta: new Date()
        }
      });
      console.log(`[WEBHOOK] ✅ Respuesta enviada: "${respuesta}"`);
    }
  } catch (error) {
    console.error('[WEBHOOK] Error generando respuesta:', error);
  }
}

// Generar respuesta con IA usando z-ai-web-dev-sdk
async function generateAIResponse(userMessage: string, fan: any): Promise<string> {
  try {
    const ZAI = (await import('z-ai-web-dev-sdk')).default;
    const zai = await ZAI.create();

    const systemPrompt = `Tu eres Louis le Raté, un comediante francés muy popular en redes sociales.
Tu estilo es gracioso, un poco sarcástico y muy amigable con tus fans.
Respondes SIEMPRE en francés coloquial y divertido.
Usa emojis ocasionalmente.
Conoces a tus fans y los tratas como amigos.
El fan se llama ${fan.nombre || 'mon ami'} y te ha escrito ${fan.totalMensajes || 1} veces.
Sé breve pero simpático. Máximo 2-3 oraciones.`;

    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userMessage }
      ],
      temperature: 0.8,
      max_tokens: 150
    });

    return completion.choices[0]?.message?.content || 'Merci pour ton message! 😊';
  } catch (error) {
    console.error('[WEBHOOK] Error con IA, usando respuesta por defecto:', error);
    // Respuestas por defecto en francés
    const respuestas = [
      "Merci beaucoup pour ton message! Ça me fait super plaisir! 🎭",
      "Haha, tu es trop gentil! Merci de me suivre! 😊",
      "Ah oui? C'est cool! Continue à me suivre! 🎬",
      "Merci mon ami! Tu assures! 💪",
      "Trop bien! Merci pour ton soutien! 🙏"
    ];
    return respuestas[Math.floor(Math.random() * respuestas.length)];
  }
}

// Enviar mensaje a Facebook Messenger
async function sendFacebookMessage(recipientId: string, message: string): Promise<boolean> {
  try {
    const response = await fetch(
      `https://graph.facebook.com/v18.0/me/messages?access_token=${PAGE_ACCESS_TOKEN}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          recipient: { id: recipientId },
          message: { text: message }
        })
      }
    );

    const data = await response.json();
    console.log('[WEBHOOK] Respuesta de Facebook:', data);

    if (data.error) {
      console.error('[WEBHOOK] Error de Facebook:', data.error);
      return false;
    }

    return !!data.message_id;
  } catch (error) {
    console.error('[WEBHOOK] Error enviando mensaje:', error);
    return false;
  }
}

// Responder a un comentario
async function respondToComment(commentId: string, mensaje: any, fan: any) {
  try {
    const respuesta = await generateAIResponse(mensaje.mensajeRecibido, fan);

    const response = await fetch(
      `https://graph.facebook.com/v18.0/${commentId}/comments?access_token=${PAGE_ACCESS_TOKEN}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: respuesta })
      }
    );

    const data = await response.json();

    if (data.id) {
      await db.mensaje.update({
        where: { id: mensaje.id },
        data: {
          mensajeEnviado: respuesta,
          respondido: true,
          fechaRespuesta: new Date()
        }
      });
      console.log(`[WEBHOOK] ✅ Comentario respondido: "${respuesta}"`);
    }
  } catch (error) {
    console.error('[WEBHOOK] Error respondiendo comentario:', error);
  }
}
