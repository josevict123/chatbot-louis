import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET() {
  try {
    // Obtener últimos 50 mensajes con información del fan
    const mensajes = await db.mensaje.findMany({
      take: 50,
      orderBy: { createdAt: 'desc' },
      include: {
        fan: {
          select: {
            nombre: true,
            facebookId: true,
            totalMensajes: true
          }
        }
      }
    });

    // Obtener estadísticas
    const [totalMensajes, totalFans, respondidos] = await Promise.all([
      db.mensaje.count(),
      db.fan.count(),
      db.mensaje.count({ where: { respondido: true } })
    ]);

    return NextResponse.json({
      mensajes,
      stats: { totalMensajes, totalFans, respondidos }
    });
  } catch (error) {
    console.error('Error en dashboard:', error);
    return NextResponse.json(
      { mensajes: [], stats: { totalMensajes: 0, totalFans: 0, respondidos: 0 } },
      { status: 500 }
    );
  }
}
